﻿using System.Collections;
using System.Collections.Generic;

namespace TaskAPI.Models
{
    public interface ITaskRepository
    {
        Task GetTask(int id);
        void DeleteTask(int id);
        void UpdateTask(int id, Task task);
        Task AddTask(Task task);
        List<Task> GetAllTasks();

    }
}
