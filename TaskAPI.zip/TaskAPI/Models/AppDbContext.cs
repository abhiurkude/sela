﻿using Microsoft.EntityFrameworkCore;

namespace TaskAPI.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> otions) :base(otions)
        {
            
        }

        public DbSet<Task> Tasks { get; set; }
    }
}
