﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.Collections.Generic;
using System.Linq;

namespace TaskAPI.Models
{
    public class TaskRepository : ITaskRepository
    {
        public TaskRepository(AppDbContext context)
        {
            Context = context;
        }

        private AppDbContext Context { get; }

        public Task AddTask(Task task)
        {
            Context.Tasks.Add(task);
            Context.SaveChanges();
            return task;
        }

        public Task DeleteTask(int id)
        {
            Task task = Context.Tasks.Find(id);
            if(task != null)
            {
                Context.Tasks.Remove(task);
                Context.SaveChanges();
            }
            return task;
        }

        public List<Task> GetAllTasks()
        {
            return Context.Tasks.ToList();
        }

        public Task GetTask(int id)
        {
            return Context.Tasks.Find(id);
        }

        public Task UpdateTask(Task taskChange)
        {
            var task = Context.Tasks.Attach(taskChange);
            task.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            Context.SaveChanges();
            return taskChange;
        }
    }
}
