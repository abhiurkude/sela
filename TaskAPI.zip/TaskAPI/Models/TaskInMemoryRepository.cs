﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using static Microsoft.AspNetCore.Hosting.Internal.HostingApplication;

namespace TaskAPI.Models
{
    public class TaskInMemoryRepository : ITaskRepository
    {
        private List<Task> tasks = new List<Task>();
        public TaskInMemoryRepository()
        {
            tasks = new List<Task>()
            {  
                new Task(){ Id = 1, Title = "Meet", Description = "Meeting", Status = "In Progress", DueDate = DateTime.Now },
                new Task(){ Id = 2, Title = "Shop", Description = "Shoping", Status = "In Progress", DueDate = DateTime.Now },
                new Task(){ Id = 3, Title = "Trade", Description = "Trading", Status = "In Progress", DueDate = DateTime.Now },
            };

        }
        public Task AddTask(Task task)
        {
            task.Id = tasks.Select(i => i.Id).Max() + 1;
            tasks.Add(task);
            return task;
        }

        public void DeleteTask(int id)
        {
            Task task = tasks.FirstOrDefault(e => e.Id == id);
            if (task != null)
            {
                tasks.Remove(task);
            }
        }

        public List<Task> GetAllTasks()
        {
            return tasks;
        }

        public Task GetTask(int id)
        {
            return tasks.FirstOrDefault(e => e.Id == id);
        }

        public void UpdateTask(int id, Task task)
        {
            var editTask = tasks.FirstOrDefault(e => e.Id == id);
            editTask.Title = task.Title;
            editTask.Status = task.Status;
        }
    }
}
