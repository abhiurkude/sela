import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Task } from '../model/task.model';
import { StatusModel } from '../model/status.model';
import { TaskService } from '../services/task-service.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-manage',
  templateUrl: './manage.component.html',
  styleUrls: ['./manage.component.scss']
})
export class ManageComponent implements OnInit {

  pageName:string = '';

  taskData:Task = { id: 0, title:'', description:'', status:'', dueDate: new Date() };

  statusList : StatusModel[] = [
    {id : 1, name : 'To Do'},
    {id : 2, name : 'In Progress'},
    {id : 3, name : 'Done'}
  ];

  constructor(private taskService:TaskService, private _route: ActivatedRoute) { }

  ngOnInit(): void {
    const id = +this._route.snapshot.params['id'];
    this.getTask(id);
  }

  public saveTask(newTask : Task) : void
  {
    console.log(newTask);
    if (newTask.id === 0)
    {

      this.taskService.addTask(newTask).subscribe((dt)=>{
        console.log('data is ', dt);
      })
    }
    else
    {
      this.taskService.updateTask(newTask.id, newTask).subscribe((dt)=>{
        console.log('data is ', dt);
      })
    }
    
  }

  private getTask(id:number) {
    console.log('gettask for task id ' + id);
    if (id !== 0) {
      this.pageName = "Edit";
      if (id !== 0) {
      this.taskService.getTask(id).subscribe((dt) =>
      {
        this.taskData = dt;
      });
    }
      //this.taskData = { id: 3, title: 'Eat', description: 'Eating', status: '3', dueDate: new Date()};
    }
    else
    {
      this.pageName = "Create";
    }
    
  }  
}
