import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Task } from '../model/task.model';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  private path : string = 'http://localhost:12084/api/';
  constructor(private http: HttpClient) {  }
  public getTasks(): Observable<Task[]> {
    return this.http.get<Task[]>(this.path + 'values');
  }

  public getTask(id:number): Observable<Task> {
    return this.http.get<Task>(this.path + 'values/' +id);
  }

  public addTask(task:Task): Observable<Task[]> {
    return this.http.post<Task[]>(this.path + 'values',task);
  }

  public updateTask(id:number, task:Task): Observable<Task[]> {
    return this.http.put<Task[]>(this.path + 'values/' + id,task);
  }

  public deleteTask(id:number): Observable<void> {
    return this.http.delete<void>(this.path + 'values/' + id);
  }
}
