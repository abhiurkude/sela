import { Component, OnInit } from '@angular/core';
import { TaskService } from '../services/task-service.service';
import { Task } from '../model/task.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  taskData:Task[] = [];
  constructor(private taskService:TaskService, private _router: Router) { }

  ngOnInit(): void {
    this.getTask();
  }

  private getTask() {
    this.taskService.getTasks().subscribe((dt)=>{
      console.log('data is ', dt);
      this.taskData = dt;
    })
    // this.taskData = [
    //   { id: 1, title: 'Meet', description: 'Meeting', status: 'Done', dueDate: new Date('01/01/2024')},
    //   { id: 2, title: 'Shop', description: 'Shoping', status: 'Pending', dueDate: new Date('01/01/2024')},
    //   { id: 3, title: 'Eat', description: 'Eating', status: 'Pending', dueDate: new Date('01/01/2024')}
    // ]
  }

  deleteTask(id: number){
    console.log('deleteing task id ' + id);
    this.taskService.deleteTask(id);
    // const i = this.taskData.findIndex(e => e.id = id);
    // if (i !== -1)
    // {
    //   this.taskData.splice(i, 1);
    // }
  }

  editTask(id:number){
    console.log('editing task id ' + id);
    this._router.navigate(['/edit', id]);
  }

}
